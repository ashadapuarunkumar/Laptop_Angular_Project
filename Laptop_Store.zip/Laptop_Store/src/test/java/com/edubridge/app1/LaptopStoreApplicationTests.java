package com.edubridge.app1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
