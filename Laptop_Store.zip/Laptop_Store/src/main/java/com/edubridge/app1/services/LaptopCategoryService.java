package com.edubridge.app1.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.app1.entity.Laptop;
import com.edubridge.app1.entity.LaptopCategory;
import com.edubridge.app1.repo.LaptopCategoryRepository;
import com.edubridge.app1.repo.LaptopRepository;



@Service
public class LaptopCategoryService {

	@Autowired
	private LaptopCategoryRepository laptopCategoryRepository;
		
	@Autowired
	private LaptopRepository laptopRepository;

	public Laptop addLaptopToCategory(Long categoryId,Laptop laptop) {
		
		Optional<LaptopCategory>optional=laptopCategoryRepository.findById(categoryId);
		
		if(optional.isPresent()) {
			LaptopCategory category=optional.get();
			laptop.setCategory(category);
			return laptopRepository.save(laptop);
		}else {
			throw new RuntimeException("category not found");
		}
	}
	
}