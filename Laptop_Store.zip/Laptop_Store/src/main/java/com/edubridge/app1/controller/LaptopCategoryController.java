package com.edubridge.app1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.app1.entity.Laptop;
import com.edubridge.app1.services.LaptopCategoryService;


@CrossOrigin("http://localhost:4200")//angular url acess by angular or any
@RestController
@RequestMapping("/api/v1")
public class LaptopCategoryController {

	@Autowired
	private LaptopCategoryService laptopCategoryService;

	@PostMapping("/category/{categoryId}/laptops")
	public ResponseEntity<Laptop> addLaptopToCategory(@PathVariable Long categoryId, @RequestBody Laptop laptop) {
		laptopCategoryService.addLaptopToCategory(categoryId, laptop);

		return new ResponseEntity<>(HttpStatus.OK);
	}
}
