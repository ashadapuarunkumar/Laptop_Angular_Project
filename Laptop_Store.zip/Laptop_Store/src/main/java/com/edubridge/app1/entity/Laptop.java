package com.edubridge.app1.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="laptops")
public class Laptop {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id;
    private String name;
    private String description;
    private Double price;
    private String imageURL;
    private Long unitsInStock;
	
	 @ManyToOne(fetch=FetchType.LAZY)
	 @JoinColumn(name="category_id")
	 private LaptopCategory category;
	 
	 
}