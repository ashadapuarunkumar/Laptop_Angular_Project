package com.edubridge.app1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.app1.repo.LaptopRepository;


@Service
public class LaptopService {
	
	@Autowired
	private LaptopRepository repo;
}
