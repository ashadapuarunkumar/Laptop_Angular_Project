import { Component } from '@angular/core';
import { Laptop } from '../../common/laptop';
import { LaptopService } from '../../service/laptop.service';

@Component({
  selector: 'app-laptop-list',
  standalone: false,
  
  templateUrl: './laptop-list.component.html',
  styleUrl: './laptop-list.component.css'
})
export class LaptopListComponent {
  laptop: Laptop[] = [];
  constructor(private laptopService: LaptopService) { }

  listLaptop() {
    this.laptopService.getlaptopList().subscribe((data) => {
      this.laptop = data;
      console.log(data);
    });
  }

  ngOnInit() {
    this.listLaptop();
  }
}


