import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LaptopCategoryEditComponent } from './laptop-category-edit.component';

describe('LaptopCategoryEditComponent', () => {
  let component: LaptopCategoryEditComponent;
  let fixture: ComponentFixture<LaptopCategoryEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LaptopCategoryEditComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LaptopCategoryEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
