import { Component } from '@angular/core';
import { LaptopCategoryService } from '../../service/laptop-category.service';
import { LaptopCategory } from '../../common/laptop-category';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-laptop-category-edit',
  standalone: false,
  
  templateUrl: './laptop-category-edit.component.html',
  styleUrl: './laptop-category-edit.component.css'
})
export class LaptopCategoryEditComponent {
  categoryFormGroup: FormGroup;
  laptopCategory: LaptopCategory = new  LaptopCategory();
  id: number;
  constructor(
    private formBulider: FormBuilder,
    private laptopCategoryService:  LaptopCategoryService,
    private router: Router,
    private activateRouter: ActivatedRoute
  ) { }

  ngOnInit() {
    this.categoryFormGroup = this.formBulider.group({
      category: this.formBulider.group({
        categoryName: ['', [Validators.required, Validators.pattern('[a-zA-z]+')],],
      }),
    });
    // read id given in ProductCategoryEditComponent route.
    this.id = this.activateRouter.snapshot.params['id'];
    this.laptopCategoryService.getLaptopCategory(this.id).subscribe((data) => {
      this.laptopCategory = data;
      console.log(this.laptopCategory);
    });
  }

  get categoryName() {
    return this.categoryFormGroup.get('category.categoryName');
  }

  onSubmit() {
    if (this.categoryFormGroup.invalid) {
      this.categoryFormGroup.markAllAsTouched();
      alert('invalid Form');
      return;
    }
    if (confirm('are you want to update')) {
      this.laptopCategoryService.updateLaptopCategory(this.id, this.laptopCategory).subscribe((data) => {
        alert("laptop Details are updated!");
        this.router.navigateByUrl('/laptop-category-list');
      });
    }
  }
}

