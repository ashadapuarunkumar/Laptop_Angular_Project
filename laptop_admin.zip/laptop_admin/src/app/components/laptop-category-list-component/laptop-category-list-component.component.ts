import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LaptopCategoryService } from '../../service/laptop-category.service';
import { LaptopCategory } from '../../common/laptop-category';

@Component({
  selector: 'app-laptop-category-list-component',
  standalone: false,

  templateUrl: './laptop-category-list-component.component.html',
  styleUrl: './laptop-category-list-component.component.css'
})
export class LaptopCategoryListComponentComponent {
  laptopCategories: LaptopCategory[] = [];

  constructor(
    private laptopCategoryService: LaptopCategoryService,
    private router:Router) { }

  listLaptopCategory() {
    this.laptopCategoryService.getLaptopCategories().subscribe((data) => {
      this.laptopCategories = data;
      console.log(data);
    });
  }

  ngOnInit() {
    this.listLaptopCategory();
  }
  removeCategory(id:number){
    if (confirm('Are you sure to delete')){
      this.laptopCategoryService
      .deleteLaptopCategory(id)
      .subscribe((data)=>{
        alert('category is removed');
        this.listLaptopCategory();
      });
    }
  }
  showLaptopCategoryEdit(id:number){
    this.router.navigate(['laptop-category-edit',id])
  }
}


