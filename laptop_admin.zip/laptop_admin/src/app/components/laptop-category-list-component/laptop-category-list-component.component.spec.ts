import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LaptopCategoryListComponentComponent } from './laptop-category-list-component.component';

describe('LaptopCategoryListComponentComponent', () => {
  let component: LaptopCategoryListComponentComponent;
  let fixture: ComponentFixture<LaptopCategoryListComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LaptopCategoryListComponentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LaptopCategoryListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
