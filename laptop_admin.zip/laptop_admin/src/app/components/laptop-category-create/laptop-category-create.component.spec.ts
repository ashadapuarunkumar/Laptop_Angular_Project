import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LaptopCategoryCreateComponent } from './laptop-category-create.component';

describe('LaptopCategoryCreateComponent', () => {
  let component: LaptopCategoryCreateComponent;
  let fixture: ComponentFixture<LaptopCategoryCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LaptopCategoryCreateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LaptopCategoryCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
