import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LaptopCategoryService } from '../../service/laptop-category.service';
import { Router } from '@angular/router';
import { LaptopCategory } from '../../common/laptop-category';

@Component({
  selector: 'app-laptop-category-create',
  standalone: false,
  
  templateUrl: './laptop-category-create.component.html',
  styleUrl: './laptop-category-create.component.css'
})
export class LaptopCategoryCreateComponent {
  
  categoryFormGroup: FormGroup;
  laptopCategory: any;
  
  constructor(
    private formBulider: FormBuilder,
    private laptopCategoryService: LaptopCategoryService,
    private router: Router
  ) { }

  ngOnInit() {
    this.categoryFormGroup = this.formBulider.group({
      category: this.formBulider.group({
        categoryName: ['', [Validators.required,Validators.pattern('[a-zA-z]+')],],
      }),
    });
  }

  get categoryName() {
    return this.categoryFormGroup.get('category.categoryName');
  }

  onSubmit() {
    if (this.categoryFormGroup.invalid) {
      this.categoryFormGroup.markAllAsTouched();
      alert('invalid Form');
      return;
    }

    
    let laptopCategory=new LaptopCategory();
    laptopCategory=this.categoryFormGroup.controls['category'].value;

    console.log(laptopCategory)
    
    this.laptopCategoryService.createLaptopCategory(laptopCategory).subscribe((data)=>{
      alert('new category added');
      this.router.navigateByUrl('/laptop-category-list');
    });
  }
}



