import { Component } from '@angular/core';
import { Laptop } from '../../common/laptop';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LaptopService } from '../../service/laptop.service';
import { LaptopCategoryService } from '../../service/laptop-category.service';
import { Router } from '@angular/router';
import { LaptopCategory } from '../../common/laptop-category';

@Component({
  selector: 'app-add-laptop',
  standalone: false,

  templateUrl: './add-laptop.component.html',
  styleUrl: './add-laptop.component.css'
})
export class AddLaptopComponent {
  laptopFormGroup: FormGroup;

  laptopCategory: LaptopCategory[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private laptopService: LaptopService,
    private laptopCategoryService: LaptopCategoryService,
    private router: Router
  ) { }
  ngOnInit() {
    this.laptopFormGroup = this.formBuilder.group({
      laptop: this.formBuilder.group({
        name: ['', [Validators.required]],
        description: ['', [Validators.required]],
        price: ['', [Validators.required]],
        imageUrl: ['', [Validators.required]],
        unitsInStock: ['', [Validators.required]],
        category: ['', [Validators.required]],

      }),
    });
    this.listLaptopCategory();
  }
  // These are getter methods of every individual property.
  get name() {
    return this.laptopFormGroup.get('laptop.name');
  }
  get description() {
    return this.laptopFormGroup.get('laptop.description');
  }
  get price() {
    return this.laptopFormGroup.get('laptop.price');
  }
  get imageUrl() {
    return this.laptopFormGroup.get('laptop.imageUrl');
  }
  get unitsInStock() {
    return this.laptopFormGroup.get('laptop.unitInStock');
  }
  get category() {
    return this.laptopFormGroup.get('laptop.category');
  }
  listLaptopCategory() {
    this.laptopCategoryService.getLaptopCategories().subscribe((data) => {
      this.laptopCategory = data;
    });
  }
  onSubmit() {
    if (this.laptopFormGroup.invalid) {
      this.laptopFormGroup.markAllAsTouched();
      // all the controlled properties should be touched.
      alert('Invalid Form');
      return;
    }
    // if the form is valid we can

    let laptop = new Laptop();
    laptop = this.laptopFormGroup.controls['laptop'].value;

    this.laptopService.createLaptop(laptop.category.id, laptop).subscribe((data) => {
      alert('New Laptop is added!');
      this.router.navigateByUrl('/laptop-list');
    });

  }
}
