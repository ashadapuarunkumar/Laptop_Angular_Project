import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideHttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LaptopCategoryListComponentComponent } from './components/laptop-category-list-component/laptop-category-list-component.component';
import { LaptopCategoryCreateComponent } from './components/laptop-category-create/laptop-category-create.component';
import { LaptopCategoryEditComponent } from './components/laptop-category-edit/laptop-category-edit.component';
import { LaptopListComponent } from './components/laptop-list/laptop-list.component';
import { AddLaptopComponent } from './components/add-laptop/add-laptop.component';

@NgModule({
  declarations: [
    AppComponent,
    LaptopCategoryListComponentComponent,
    LaptopCategoryCreateComponent,
    LaptopCategoryEditComponent,
    LaptopListComponent,
    AddLaptopComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ provideHttpClient()],
  bootstrap: [AppComponent]
})
export class AppModule { }
