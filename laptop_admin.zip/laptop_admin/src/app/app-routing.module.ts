import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LaptopListComponent } from './components/laptop-list/laptop-list.component';
import { LaptopCategoryListComponentComponent } from './components/laptop-category-list-component/laptop-category-list-component.component';
import { LaptopCategoryCreateComponent } from './components/laptop-category-create/laptop-category-create.component';
import { LaptopCategoryEditComponent } from './components/laptop-category-edit/laptop-category-edit.component';
import { AddLaptopComponent } from './components/add-laptop/add-laptop.component';

const routes: Routes = [
  { path:'laptop-list',component:LaptopListComponent},
  { path: 'laptop-category-list',component:LaptopCategoryListComponentComponent},
  { path: 'laptop-category-create',component:LaptopCategoryCreateComponent},
  { path: 'laptop-category-edit/:id',component:LaptopCategoryEditComponent},
  { path:'add-laptop',component:AddLaptopComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
