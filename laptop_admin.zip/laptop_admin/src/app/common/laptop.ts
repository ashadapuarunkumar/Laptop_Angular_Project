import { LaptopCategory } from "./laptop-category";

export class Laptop {

  id: number;

  name: string;

  description: string;

  price: number;

  imageURL: string;

  unitsInStock:string;


  category:LaptopCategory;

}
