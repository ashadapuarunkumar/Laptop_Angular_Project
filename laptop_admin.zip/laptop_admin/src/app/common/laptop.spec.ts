import { Laptop } from './laptop';

describe('Laptop', () => {
  it('should create an instance', () => {
    expect(new Laptop()).toBeTruthy();
  });
});
