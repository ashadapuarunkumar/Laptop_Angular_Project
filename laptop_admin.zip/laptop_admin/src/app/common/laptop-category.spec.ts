import { LaptopCategory } from './laptop-category';

describe('LaptopCategory', () => {
  it('should create an instance', () => {
    expect(new LaptopCategory()).toBeTruthy();
  });
});
