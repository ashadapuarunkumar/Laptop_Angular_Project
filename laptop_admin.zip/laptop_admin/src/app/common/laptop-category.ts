export class LaptopCategory {
    id:number;
    categoryName:string;
}

