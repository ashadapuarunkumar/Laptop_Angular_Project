import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Laptop } from '../common/laptop';
import { map } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LaptopService {


  constructor(private http:HttpClient ) { }
    getlaptopList(){
      const url='http://localhost:8181/api/laptops';
      return this.http.get<GetResponseLaptops>(url).pipe(map((response)=>response._embedded.laptops));
    }
    createLaptop(id: number,laptop: Laptop) {
      const url = 'http://localhost:8181/api/v1/category/'+id+'/laptops';
      return this.http.post<Laptop>(url, laptop);
    }

}
interface GetResponseLaptops{
  _embedded:{
    laptops:Laptop[];
  };
}
