import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LaptopCategory } from '../common/laptop-category';
import { map } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LaptopCategoryService {

  constructor(private http:HttpClient) { }

  getLaptopCategories(){
    const url="http://localhost:8181/api/laptop-category";
    return this.http.get<GetResponseLaptops>(url).pipe(map((response)=>response._embedded.laptopCategory));
  
  }

  createLaptopCategory(laptopCategory:LaptopCategory){
    console.log("createLaptopCategory() of laptopCategoryService")

    const url="http://localhost:8181/api/laptop-category";
    return this.http.post<LaptopCategory>(url, laptopCategory)
}
deleteLaptopCategory(id:number){
  const url='http://localhost:8181/api/laptop-category/'+id;
  return this.http.delete<LaptopCategory>(url)
}
getLaptopCategory(id:number){
  const url='http://localhost:8181/api/product-category/'+id;
  return this.http.get<LaptopCategory>(url)
}

updateLaptopCategory(id:number,laptopCategory:LaptopCategory){
  const url='http://localhost:8181/api/laptop-category/'+id;
  return this.http.put<LaptopCategory>(url,laptopCategory);
  
}


}interface GetResponseLaptops{
  _embedded:{
    laptopCategory:LaptopCategory[];
  };
}