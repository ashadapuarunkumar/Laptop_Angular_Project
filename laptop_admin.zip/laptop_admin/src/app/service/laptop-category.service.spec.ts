import { TestBed } from '@angular/core/testing';

import { LaptopCategoryService } from './laptop-category.service';

describe('LaptopCategoryService', () => {
  let service: LaptopCategoryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LaptopCategoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
